# Anonymous Messaging System

A web application that allows users to send and receive anonymous messages, similar to Tellonym.

## Features

- User registration and authentication
- Send anonymous messages to other users
- View received messages in a clean, modern interface
- Secure password hashing
- Responsive design

## Installation

1. Make sure you have Python 3.8+ installed
2. Install the required packages:
```bash
pip install -r requirements.txt
```

3. Run the application:
```bash
python app.py
```

4. Open your browser and navigate to `http://localhost:5000`

## Usage

1. Register for an account
2. Log in with your credentials
3. Send anonymous messages to other users by entering their username
4. View your received messages on your dashboard

## Security Features

- Passwords are securely hashed using Werkzeug's security functions
- Flask-Login handles user sessions securely
- CSRF protection enabled by default
- SQLAlchemy for safe database operations

## Technologies Used

- Flask
- SQLAlchemy
- Flask-Login
- Bootstrap 5
- SQLite

## Configuration Setup

### 1. Generate SECRET_KEY
Run this Python code to generate a secure SECRET_KEY:
```python
import secrets
secret_key = secrets.token_hex(24)
print(secret_key)
```

### 2. Google OAuth Setup
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create or select your project
3. Enable the Google+ API
4. Go to Credentials
5. Create an OAuth 2.0 Client ID
6. Add authorized redirect URIs:
   - Production: `https://[your-app-name].vercel.app/login/google/authorized`
   - Development: `http://localhost:5000/login/google/authorized`

### 3. Vercel Environment Variables
Set these in your Vercel project dashboard:
```
SECRET_KEY=[your-generated-secret-key]
GOOGLE_OAUTH_CLIENT_ID=[your-google-client-id]
GOOGLE_OAUTH_CLIENT_SECRET=[your-google-client-secret]
DATABASE_URL=[your-database-url]
```

## Local Development
1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Set environment variables in a .env file:
```
SECRET_KEY=[your-generated-secret-key]
GOOGLE_OAUTH_CLIENT_ID=[your-google-client-id]
GOOGLE_OAUTH_CLIENT_SECRET=[your-google-client-secret]
```

3. Run the application:
```bash
flask run
```

## Deployment
1. Install Vercel CLI:
```bash
npm install -g vercel
```

2. Deploy:
```bash
vercel
```

## Important Notes
- Always keep your SECRET_KEY and OAuth credentials secure
- Never commit sensitive credentials to version control
- Update Google OAuth credentials when changing domains
- Test OAuth flow in both development and production environments
